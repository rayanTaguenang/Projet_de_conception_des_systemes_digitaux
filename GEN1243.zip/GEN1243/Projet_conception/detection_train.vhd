LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
USE ieee.numeric_std.ALL;

ENTITY detection_train IS
    PORT(
        clk : IN STD_LOGIC;        -- Signal d'horloge
        reset : IN STD_LOGIC;      -- Signal de réinitialisation
		  
--switchs pour controle du code pin		  
		  SW0      		: IN std_logic; 
		  SW9      		: IN std_logic; 
		  SW8 			: IN std_logic; 
		  SW7				: IN std_logic;
		  SW6 			: IN std_logic;		  
		  key3 			: IN std_logic; --bouton pour activation/désactivation du système
       
        trig : out std_logic;     -- Signal TRIG pour déclencher le capteur1_train
        echo : in std_logic;      -- Signal ECHO du capteur1_train
		  trig1 : out std_logic;     -- Signal TRIG pour déclencher le capteur2_train
        echo1 : in std_logic;      -- Signal ECHO du capteur2_train
		  trig2 : out std_logic;     -- Signal TRIG pour déclencher le capteur3_sortie_train
        echo2 : in std_logic ;     -- Signal ECHO du capteur capteur3_sortie_train
		  trig3 : out std_logic;     -- Signal TRIG pour déclencher le capteur4_usagers
        echo3 : in std_logic ;     -- Signal ECHO du capteur4_usagers
		  
        led  : out std_logic ;     -- Sortie led pour le test des capteur 1 et 2
		  led1  : out std_logic ;     -- Sortie led pour le test du capteur 3
		  led2  : out std_logic ;     -- Sortie led pour le capteur 4
		  
        buzzer1    : BUFFER STD_LOGIC;    -- Buzzer1 présence du train
		  buzzer2    : BUFFER STD_LOGIC;    -- Buzzer2 qui urgence
        LED_rouge1 : out STD_LOGIC;  -- LED rouge pour le train
		  LED_rouge2 : out STD_LOGIC;  -- LED rouge pour les usagers
        LED_verte1 : OUT STD_LOGIC;  -- LED verte pour le train
		  
	--AFFICHEUR 7 SEGMENTS
        HEX5 : OUT STD_LOGIC_VECTOR (6 DOWNTO 0);
        HEX4 : OUT STD_LOGIC_VECTOR (6 DOWNTO 0);
        HEX3 : OUT STD_LOGIC_VECTOR (6 DOWNTO 0);
        HEX2 : OUT STD_LOGIC_VECTOR (6 DOWNTO 0);
		  HEX1 : OUT STD_LOGIC_VECTOR (6 DOWNTO 0);
        HEX0 : OUT STD_LOGIC_VECTOR (6 DOWNTO 0);
        
        servo : OUT STD_LOGIC ;          -- Sortie pour contrôler le servomoteur
		  
		   train_detecte: OUT STD_LOGIC
    );
END detection_train;

ARCHITECTURE behavior OF detection_train IS

			SIGNAL pin_correct        : std_logic := '0';  -- Indicateur de PIN correct
			signal mode_m     			: std_logic := '0';  --mode manuel
			signal mode_auto				: std_logic := '0';  --mode automatique

			signal key3_passe		: std_logic := '0';
			signal counter1      : integer := 0;          -- Compteur pour mesurer la durée de l'impulsion ECHO
			signal counter1_1     : integer := 0;          -- Compteur pour l'impulsion TRIG
			signal echo_active1  : std_logic := '0';      -- Indicateur pour savoir si l'impulsion ECHO est en cours

			signal counter2      : integer := 0;          -- Compteur pour mesurer la durée de l'impulsion ECHO
			signal counter2_1     : integer := 0;          -- Compteur pour l'impulsion TRIG
			signal echo_active2  : std_logic := '0';      -- Indicateur pour savoir si l'impulsion ECHO est en cours

			signal counter3      : integer := 0;          -- Compteur pour mesurer la durée de l'impulsion ECHO
			signal counter3_1     : integer := 0;          -- Compteur pour l'impulsion TRIG
			signal echo_active3  : std_logic := '0';      -- Indicateur pour savoir si l'impulsion ECHO est en cours

			signal counter4      : integer := 0;          -- Compteur pour mesurer la durée de l'impulsion ECHO
			signal counter4_1     : integer := 0;          -- Compteur pour l'impulsion TRIG
			signal echo_active4  : std_logic := '0';      -- Indicateur pour savoir si l'impulsion ECHO est en cours

			signal ultrason_train_1  : std_logic := '0'; --capteur1 train entré
			signal ultrason_train_2  : std_logic := '0'; --capteur2 train entré
			signal ultrason_train_3 : std_logic := '0'; --capteur3 train sorti
			signal ultrason_train_4 : std_logic := '0'; --capteur4 usagers
			signal ultrason_3_passe  : std_logic := '0';--Etat passé du capteur 3 usager
			
			constant clk_freq   : integer := 50_000_000; -- Fréquence d'horloge (50 MHz)
					 
--led rouge train		 
			SIGNAL counter_led : INTEGER := 0;    -- Compteur led clignotante pour diviser l'horloge
			SIGNAL etat_led : std_logic := '0'; -- État de la LED clignotante
			CONSTANT max_count_led : INTEGER := clk_freq; -- Compteur maximum pour led du clignotante

--buzzer1 detection du train	 
			SIGNAL counter_buzzer1 : INTEGER := 0;        -- Compteur pour le buzzer
			CONSTANT buzzer1_interval_count : INTEGER := clk_freq; -- Compteur pour 1 seconde
			signal buzzer1_active : std_logic := '0';  -- Indicateur pour savoir si le buzzer doit continuer à biper

--buzzer2 detection des usagers			
			SIGNAL counter_buzzer2 : INTEGER := 0;        -- Compteur pour le buzzer
			CONSTANT buzzer2_interval_count : INTEGER := 25000 ; -- Compteur pour buzzer2 
			signal buzzer2_active : std_logic := '0';  -- Indicateur pour savoir si le buzzer doit continuer

--cas d'urgence		
			signal urgence: std_logic := '0'; --signal de detection du cas d'urgence

			signal train_zone  : std_logic := '0'; 
				 
-- signal pour le servomoteur
			SIGNAL pwm_counter : INTEGER := 0;            -- Compteur pour générer la période PWM
			SIGNAL servo_pos : INTEGER := 25000;          -- Largeur d'impulsion pour le servomoteur (en nombre de cycles d'horloge)
			CONSTANT pwm_period : INTEGER := 1000000;      -- Période PWM de 20 ms (50 Hz)
			SIGNAL servo_signal : STD_LOGIC := '0';        -- Signal de commande du servomoteur  
			
	BEGIN
-- Gestion de la barrière
 PROCESS (clk)
    BEGIN
        IF rising_edge(clk) THEN
            IF pwm_counter < servo_pos THEN
                servo_signal <= '1';  -- Générer un niveau haut pour contrôler la position du servomoteur
            ELSE
                servo_signal <= '0';  -- Niveau bas
            END IF;

            IF pwm_counter = pwm_period THEN
                pwm_counter <= 0;  -- Réinitialiser le compteur de période PWM
            ELSE
                pwm_counter <= pwm_counter + 1;  -- Incrémenter le compteur
            END IF;
        END IF;
    END PROCESS;
    servo <= servo_signal; -- Assigner le signal de commande PWM à la sortie du servomoteur
	 
process(clk)
    begin	 
-- CAPTEUR 1 ENTREE_train
	if rising_edge(clk) then
            -- Envoyer l'impulsion TRIG
			if counter1_1 = 0 then
                trig <= '1';  -- TRIG à '1' pour déclencher le capteur
            elsif counter1_1 = 500 then  -- 500 cycles pour générer une impulsion de 10 µs
                trig <= '0';  -- TRIG à '0' après 10 µs
			end if;

            -- Incrémenter le compteur de TRIG
			if counter1_1 < 12_500_000 then  -- 12_500_000 pour répéter l'impulsion toutes les 250 ms
                counter1_1 <= counter1_1 + 1;
            else
                counter1_1 <= 0;  -- Réinitialiser après une période de 250 ms
			end if;
    
--l'impulsion ECHO, commence à incrémenter le compteur
			if echo = '1' then
				 if echo_active1 = '0' then
                    counter1 <= 0;  -- Réinitialiser le compteur au début de l'impulsion
                    echo_active1 <= '1';  -- Marquer que l'ECHO est actif
				 else
                    counter1 <= counter1 + 1;  -- Incrémenter le compteur pendant que ECHO est actif
				 end if;
			elsif echo = '0' and echo_active1 = '1' then
                -- Fin de l'impulsion ECHO, calculer la distance
                echo_active1 <= '0';  -- Marquer que l'ECHO est terminé
				 if counter1 < 43731 then  -- Exemple de seuil basé sur le calcul de la distance (15cm)
                    ultrason_train_1 <= '1';  -- L'objet est proche, allumer la LED
					else
                    ultrason_train_1 <= '0';  -- L'objet est loin, éteindre la LED
				 end if;
			end if;
			
		--CAPTEUR2 entrée train 
-- Envoyer l'impulsion TRIG
            if counter2_1 = 0 then
                trig1 <= '1';  -- TRIG à '1' pour déclencher le capteur
            elsif counter2_1 = 500 then  -- 500 cycles pour générer une impulsion de 10 µs
                trig1 <= '0';  -- TRIG à '0' après 10 µs
            end if;
 -- Incrémenter le compteur de TRIG
            if counter2_1 < 12_500_000 then  -- 12_500_000 pour répéter l'impulsion toutes les 250 ms
                counter2_1 <= counter2_1 + 1;
            else
                counter2_1 <= 0;  -- Réinitialiser après une période de 250 ms
            end if;   

--l'impulsion ECHO, commence à incrémenter le compteur       
            if echo1 = '1' then
                if echo_active2 = '0' then
                    counter2 <= 0;  -- Réinitialiser le compteur au début de l'impulsion
                    echo_active2 <= '1';  -- Marquer que l'ECHO est actif
                else
                    counter2 <= counter2 + 1;  -- Incrémenter le compteur pendant que ECHO est actif
                end if;
            elsif echo1 = '0' and echo_active2 = '1' then
				
 -- Fin de l'impulsion ECHO, calculer la distance
                echo_active2 <= '0';  -- Marquer que l'ECHO est terminé
                if counter2 < 43731 then  -- Exemple de seuil basé sur le calcul de la distance (15cm)
                    ultrason_train_2 <= '1';  -- L'objet est proche, allumer la LED
                else
                    ultrason_train_2 <= '0';  -- L'objet est loin, éteindre la LED
                end if;
            end if;
          
-- test capteurs 1 et 2 entrée du train
            IF (ultrason_train_1 = '1' OR ultrason_train_2 = '1') THEN
                led <= '1';  -- Allumer la LED
            ELSE
                led <= '0';  -- Éteindre la LED
            END IF;
	
	  -- capteur 3 sortie train 
 
-- Envoyer l'impulsion TRIG
            if counter3_1 = 0 then
                trig2 <= '1';  -- TRIG à '1' pour déclencher le capteur
            elsif counter3_1 = 500 then  -- 500 cycles pour générer une impulsion de 10 µs
                trig2 <= '0';  -- TRIG à '0' après 10 µs
            end if;
-- Incrémenter le compteur de TRIG
            if counter3_1 < 12_500_000 then  -- 12_500_000 pour répéter l'impulsion toutes les 250 ms
                counter3_1 <= counter3_1 + 1;
            else
                counter3_1 <= 0;  -- Réinitialiser après une période de 250 ms
            end if;	
				
--l'impulsion ECHO, commence à incrémenter le compteur     
            if echo2 = '1' then
                if echo_active3 = '0' then
                    counter3 <= 0;  -- Réinitialiser le compteur au début de l'impulsion
                    echo_active3 <= '1';  -- Marquer que l'ECHO est actif
                else
                    counter3 <= counter3 + 1;  -- Incrémenter le compteur pendant que ECHO est actif
                end if;
            elsif echo2 = '0' and echo_active3 = '1' then
				
-- Fin de l'impulsion ECHO, calculer la distance
                echo_active3 <= '0';  -- Marquer que l'ECHO est terminé
					 ultrason_3_passe <= ultrason_train_3; --mise ajour de l,etat précédent du capteur 3
                if counter3 < 43731 then  -- Exemple de seuil basé sur le calcul de la distance (15cm)
                    ultrason_train_3 <= '1';  -- L'objet est proche, allumer la LED
                else
                    ultrason_train_3 <= '0';  -- L'objet est loin, éteindre la LED
                end if;
            end if;
        	  
--test capteur 3 sortie du train
            IF (ultrason_train_3 = '1') THEN
					  led1 <= '1';
				 else 
				  led1 <= '0';
				end if;

				
      --capteur 4 usagers
-- Envoyer l'impulsion TRIG
            if counter4_1 = 0 then
                trig3 <= '1';  -- TRIG à '1' pour déclencher le capteur
            elsif counter4_1 = 500 then  -- 500 cycles pour générer une impulsion de 10 µs
                trig3 <= '0';  -- TRIG à '0' après 10 µs
            end if;

            -- Incrémenter le compteur de TRIG
            if counter4_1 < 12_500_000 then  -- 12_500_000 pour répéter l'impulsion toutes les 250 ms
                counter4_1 <= counter4_1 + 1;
            else
                counter4_1 <= 0;  -- Réinitialiser après une période de 250 ms
            end if;
				
--l'impulsion ECHO, commence à incrémenter le compteur
        
            if echo3 = '1' then
                if echo_active4 = '0' then
                    counter4 <= 0;  -- Réinitialiser le compteur au début de l'impulsion
                    echo_active4 <= '1';  -- Marquer que l'ECHO est actif
                else
                    counter4 <= counter4 + 1;  -- Incrémenter le compteur pendant que ECHO est actif
                end if;
            elsif echo3 = '0' and echo_active4 = '1' then
                -- Fin de l'impulsion ECHO, calculer la distance
                echo_active4 <= '0';  -- Marquer que l'ECHO est terminé
                if counter4 < 43731 then  -- Exemple de seuil basé sur le calcul de la distance (15cm)
                    ultrason_train_4 <= '1';  -- L'objet est proche, allumer la LED
                else
                    ultrason_train_4 <= '0';  -- L'objet est loin, éteindre la LED
                end if;
            end if;
       
-- test capteur 3 sortie train
            IF (ultrason_train_4 = '1') THEN
					  led2 <= '1';
				 else 
				  led2 <= '0';
				end if;
		end if;			  
end process;

 
-- Processus pour la logique de détection globale du train
PROCESS (clk)
BEGIN
-- module code pin
  if (SW9 = '1' and SW8 = '0' and SW7 = '1' and SW6 = '0') then
        pin_correct <= '1';
    else
        pin_correct <= '0';
    end if; 
  if falling_edge(key3) then
	 if pin_correct = '1' then
				mode_m<=not mode_m; -- activation/désactivation du système
			end if;			
   end if;
			
-- module détection de train dans la zone
	if(ultrason_train_1 = '1' or ultrason_train_2 = '1') THEN
		train_zone <='1';
	  ELSIF (ultrason_3_passe ='1' and ultrason_train_3 = '0') then
		train_zone <='0';
	end if;

	IF  mode_m = '1' THEN 
	
			counter_led <= 0;-- reinitialiser le compteur de le led clignotante
			etat_led <= '0'; -- eteindre la led rouge train
			buzzer1 <= '0'; -- Par défaut, le buzzer1 est éteint
			counter_buzzer1 <= 0; --compteur buzzer1 a 0
			buzzer1_active <= '0';  -- Désactiver le buzzer1
			buzzer2 <= '0'; -- Par défaut, le buzzer2 est éteint
			counter_buzzer2 <= 0; --compteur buzzer2 a 0
			buzzer2_active <= '0';  -- Désactiver le buzzer2
			LED_rouge2<= '0';  -- Eteindre la led des usagers 
			LED_verte1<= '0';  -- Éteindre la LED verte du train
			train_zone <='0'; --reinitialiser train dans la zone
			urgence	<= '0'; --module urgence reinitialisé
			
--Afficher passer tant que l'opérateur ne ferme pas la barriere
			HEX5 <= "0001100";  -- Afficher 'P'
			HEX4 <= "0001000";  -- Afficher 'A'
			HEX3 <= "0010010";  -- Afficher 'S'
			HEX2 <= "0010010";  -- Afficher 'S'
			HEX1 <= "0000110";  -- Afficher 'E'
			HEX0 <= "1001110";  -- Afficher 'R'
			servo_pos <= 25000; -- ouvrir la barrière
			
--controle du système par l'oppérateur	en mode manuel
	if  SW0 = '1' then
			servo_pos <= 75000; -- Fermer la barrère
			LED_rouge2 <= '1';  -- Allumer la LED rouge des usagers
			LED_verte1 <= '1';  -- Allumer la LED verte du train
			buzzer1_active <= '1';  -- Activer le buzzer1 pour le passage du train
-- Affichage "arret" lors du passage du train
			HEX5 <= "0001000";  -- Afficher 'A'
			HEX4 <= "1001110";  -- Afficher 'R'
			HEX3 <= "1001110";  -- Afficher 'R'
			HEX2 <= "0000110";  -- Afficher 'E'
			HEX1 <= "0000111";  -- Afficher 'T'
			HEX0 <= "1111111";  -- Effacer ce segment
		else
				buzzer1_active <= '0';  -- Désactiver le buzzer de detection de train
				LED_rouge2<= '0';  -- Eteindre la led rouge des usagers 
				LED_verte1 <= '0';  -- Éteindre la LED verte du train
				
--Afficher "passer" pour autoriser les usagers 				
				HEX5 <= "0001100";  -- Afficher 'P'
				HEX4 <= "0001000";  -- Afficher 'A'
				HEX3 <= "0010010";  -- Afficher 'S'
				HEX2 <= "0010010";  -- Afficher 'S'
				HEX1 <= "0000110";  -- Afficher 'E'
				HEX0 <= "1001110";  -- Afficher 'R'
				servo_pos <= 25000; -- ouvrir la barrière
		end if;

	ELse
		IF rising_edge(clk) THEN
		
--train dans la zone				
			IF  train_zone = '1' THEN	
			
				LED_rouge2 <= '1';  -- Allumer la LED rouge des usagers
				LED_verte1 <= '1';  -- Allumer la LED verte du train
				buzzer1_active <= '1';  -- Activer le buzzer1 pour le passage du train
				servo_pos <= 75000; -- Fermer la barrère

-- Affichage "arret" lors du passage du train
				HEX5 <= "0001000";  -- Afficher 'A'
				HEX4 <= "1001110";  -- Afficher 'R'
				HEX3 <= "1001110";  -- Afficher 'R'
				HEX2 <= "0000110";  -- Afficher 'E'
				HEX1 <= "0000111";  -- Afficher 'T'
				HEX0 <= "1111111";  -- Effacer ce segment
			else		
				buzzer1_active <= '0';  -- Désactiver le buzzer
				LED_rouge2<= '0';  -- Eteindre la led rouge des usagers 
				LED_verte1 <= '0';  -- Éteindre la LED verte du train
				
--Afficher "passer" pour autoriser les usagers 				
				HEX5 <= "0001100";  -- Afficher 'P'
				HEX4 <= "0001000";  -- Afficher 'A'
				HEX3 <= "0010010";  -- Afficher 'S'
				HEX2 <= "0010010";  -- Afficher 'S'
				HEX1 <= "0000110";  -- Afficher 'E'
				HEX0 <= "1001110";  -- Afficher 'R'
				servo_pos <= 25000; -- ouvrir la barrière  
			end if;
			

--module buzzer1
			IF buzzer1_active = '1' THEN
				IF counter_buzzer1 = buzzer1_interval_count THEN
					buzzer1 <= NOT buzzer1;  -- Inverser l'état du buzzer
					counter_buzzer1 <= 0;   -- Réinitialiser le compteur
				ELSE
					counter_buzzer1 <= counter_buzzer1 + 1;  -- Incrémenter le compteur
				END IF;
			else 
				buzzer1 <= '0';
			END IF;
			
--module buzzer2		
			IF buzzer2_active = '1' THEN
				IF counter_buzzer2 = buzzer2_interval_count THEN
					buzzer2 <= NOT buzzer2;  -- Inverser l'état du buzzer
					counter_buzzer2 <= 0;   -- Réinitialiser le compteur
				ELSE
					counter_buzzer2 <= counter_buzzer2 + 1;  -- Incrémenter le compteur
				END IF;
			else 
				buzzer2 <= '0';
			END IF;	
			
--Module cas d'urgence
	if ( ultrason_train_4 = '1' and (ultrason_train_1 = '1' or ultrason_train_2 = '1')) then
          urgence	<= '1';
			 elsif ultrason_train_4 = '0' then
			urgence	<= '0';
			end if;	
	
--gestion cas d'urgence			
   if urgence	= '1' then
				buzzer2_active <= '1';  -- activer le buzzer2
				buzzer1_active <= '0';  -- Activer le buzzer1
				LED_verte1 <= '0';  -- eteindre la LED verte
				LED_rouge2 <= '1';  -- Allumer la LED rouge des usager
				
				HEX5 <= "0100001";  -- Afficher 'D'
				HEX4 <= "0001000";  -- Afficher 'A'
				HEX3 <= "1001000";  -- Afficher 'N'
				HEX2 <= "1000010";  -- Afficher 'G'
				HEX1 <= "0000110";  -- Afficher 'E'
				HEX0 <= "1001110";  -- Afficher 'R'
				servo_pos <= 25000; -- ouvrir la barrière
				else
				buzzer2_active <= '0';  -- Désactiver le buzzer2 usagers
		end if;
		
--processus clignotement led rouge	
			if (urgence = '1') then
            IF (counter_led < max_count_led)  THEN
                counter_led <= counter_led + 1;
            ELSE
                counter_led <= 0;
                etat_led<= NOT etat_led; -- Inverser l'état de la LED du train pour la faire clignoter
            END IF;
			else 
			 etat_led <= '0';
			end if;
LED_rouge1 <= etat_led; --mise a jour de la led du train
	 END IF;
	END IF;
END PROCESS;
END behavior;