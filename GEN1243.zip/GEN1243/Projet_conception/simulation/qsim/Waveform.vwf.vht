-- Copyright (C) 2022  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and any partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details, at
-- https://fpgasoftware.intel.com/eula.

-- *****************************************************************************
-- This file contains a Vhdl test bench with test vectors .The test vectors     
-- are exported from a vector file in the Quartus Waveform Editor and apply to  
-- the top level entity of the current Quartus project .The user can use this   
-- testbench to simulate his design using a third-party simulation tool .       
-- *****************************************************************************
-- Generated on "11/18/2024 19:24:54"
                                                             
-- Vhdl Test Bench(with test vectors) for design  :          detection_train
-- 
-- Simulation tool : 3rd Party
-- 

LIBRARY ieee;                                               
USE ieee.std_logic_1164.all;                                

ENTITY detection_train_vhd_vec_tst IS
END detection_train_vhd_vec_tst;
ARCHITECTURE detection_train_arch OF detection_train_vhd_vec_tst IS
-- constants                                                 
-- signals                                                   
SIGNAL capteur1 : STD_LOGIC;
SIGNAL capteur2 : STD_LOGIC;
SIGNAL clk : STD_LOGIC;
SIGNAL reset : STD_LOGIC;
SIGNAL train_detecte : STD_LOGIC;
COMPONENT detection_train
	PORT (
	capteur1 : IN STD_LOGIC;
	capteur2 : IN STD_LOGIC;
	clk : IN STD_LOGIC;
	reset : IN STD_LOGIC;
	train_detecte : OUT STD_LOGIC
	);
END COMPONENT;
BEGIN
	i1 : detection_train
	PORT MAP (
-- list connections between master ports and signals
	capteur1 => capteur1,
	capteur2 => capteur2,
	clk => clk,
	reset => reset,
	train_detecte => train_detecte
	);

-- clk
t_prcs_clk: PROCESS
BEGIN
LOOP
	clk <= '0';
	WAIT FOR 10000 ps;
	clk <= '1';
	WAIT FOR 10000 ps;
	IF (NOW >= 1000000 ps) THEN WAIT; END IF;
END LOOP;
END PROCESS t_prcs_clk;

-- capteur1
t_prcs_capteur1: PROCESS
BEGIN
LOOP
	capteur1 <= '0';
	WAIT FOR 20000 ps;
	capteur1 <= '1';
	WAIT FOR 20000 ps;
	IF (NOW >= 1000000 ps) THEN WAIT; END IF;
END LOOP;
END PROCESS t_prcs_capteur1;

-- capteur2
t_prcs_capteur2: PROCESS
BEGIN
	FOR i IN 1 TO 16
	LOOP
		capteur2 <= '0';
		WAIT FOR 30000 ps;
		capteur2 <= '1';
		WAIT FOR 30000 ps;
	END LOOP;
	capteur2 <= '0';
	WAIT FOR 30000 ps;
	capteur2 <= '1';
WAIT;
END PROCESS t_prcs_capteur2;

-- reset
t_prcs_reset: PROCESS
BEGIN
	reset <= '0';
WAIT;
END PROCESS t_prcs_reset;
END detection_train_arch;
